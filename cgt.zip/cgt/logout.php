<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Network Analysis</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/sb-admin.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="css/plugins/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    
		
		
		<div class="row" style="color:white">
			<center>
			
<?php
    error_reporting(E_ERROR);
	require('config.php');  
if(isset($_GET['uid'])){

	$user_id = $_GET['uid'];
	$get_posts="select * from userlogin where id='$user_id'";  //Read 5 posts randomly
    $run_posts=mysql_query($get_posts);
	
						$update = mysql_query("UPDATE `cgt`.`userlogin` SET `status` = 'loggedout' WHERE `userlogin`.`id` = $user_id;");
						
						while($row_posts = mysql_fetch_array($run_posts))
							{
							   $user_id=$row_posts['id'];
							   $user_name=$row_posts['username'];
							   $user_status=$row_posts['status'];
							}
							echo "<strong>$user_name</strong> logged out Successfully !";
								
								
}
?>
			
			
			
			

<div style="padding-top:10px;">
<button class="btn btn-lg btn-default"><a href="index.php" style="text-decoration:none;">Home</a></button>  
</div>
			
			
			
			</center>
		</div>
        <!-- /#page-wrapper -->

    
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <!-- Morris Charts JavaScript -->
    <script src="js/plugins/morris/raphael.min.js"></script>
    <script src="js/plugins/morris/morris.min.js"></script>
    <script src="js/plugins/morris/morris-data.js"></script>

</body>

</html>
