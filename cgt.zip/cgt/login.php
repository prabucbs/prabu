<?php
	error_reporting(E_ERROR);
	require('config.php');       /*or die("Cannot find the config file.");*/
	$sql = mysql_query("SELECT * FROM `userlogin` WHERE `status` = 'loggedin'");
	
	$user_status = "loggedout";
	if($sql){  
							$get_cats = "select * from userlogin";
							$runs_cats = mysql_query($get_cats);
		                  while($cats_row = mysql_fetch_array($runs_cats))
							{
								$user_name = $cats_row['username'];
								$user_status = $cats_row['status'];
								$user_id = $cats_row['id'];
								if($user_status == "loggedin") /*User is logged in already*/
								{
								echo "id is $user_id<br>";
								echo "status is $user_status";
							    header("Location: user.php?uid=$user_id");
								break;
								}
		                  	}
							if($user_status == "loggedout"){
						                                        /*All users are logged out*/
							    header("Location: loginform.php");					
							}
	}

?>