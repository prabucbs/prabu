<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Network Analysis</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/sb-admin.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">Home</a>
            </div>
            <!-- Top Menu Items -->
            <ul class="nav navbar-right top-nav">
              
                
           <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i>
					
					<?php
                     error_reporting(E_ERROR);
	                 require('config.php');  
                     if(isset($_GET['uid'])){

	                 $user_id = $_GET['uid'];
	                 $get_posts="select * from userlogin where id='$user_id'";  //Read 5 posts randomly
                     $run_posts=mysql_query($get_posts);
	
						$update = mysql_query("UPDATE `cgt`.`userlogin` SET `status` = 'loggedin' WHERE `userlogin`.`id` = $user_id;");
						
						while($row_posts = mysql_fetch_array($run_posts))
							{
							   $user_id=$row_posts['id'];
							   $user_name=$row_posts['username'];
							   $user_status=$row_posts['status'];
							}
							echo "
								<strong>$user_name</strong>
								";
}
                     ?>
					<b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        
                        <li>
						    <a href="logout.php?uid=<?php echo $user_id?>" style="padding:10px; text-decoration:none"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
                            
                        </li>
                    </ul>
                </li>
			   
         
            </ul>
            <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
                  <li >
                        <a href="user.php?uid=<?php $user_id = $_GET['uid']; echo $user_id?>"><i class="fa fa-fw fa-search"></i>Search</a>
                    </li>
                    <li>
                        <a href="sites.php?uid=<?php $user_id = $_GET['uid']; echo $user_id?>"><i class="fa fa-fw fa-trophy"></i>List of sites</a>
                    </li>
                    <li>
                          <a href="new.php?uid=<?php $user_id = $_GET['uid']; echo $user_id?>"><i class="fa fa-fw fa-trophy"></i>Add new site</a>
                    </li>
                    
                    <li class="active">
                        <a href="tables.php?uid=<?php $user_id = $_GET['uid']; echo $user_id?>"><i class="fa fa-fw fa-trophy"></i>Analysis</a>
                    </li> 
                  
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </nav>

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Analysis
                        </h1>
                        <ol class="breadcrumb">
                            <li>
                                <i class="fa fa-dashboard"></i>  <a href="index.html">Dashboard</a>
                            </li>
                            <li class="active">
                                <i class="fa fa-table"></i> Tables
                            </li>
                        </ol>
                    </div>
                </div>
                <!-- /.row -->
				
				
				
				

                <div class="row">
                    <div class="col-lg-12">
                        <div class="table-responsive">
						
						<!--php-->
						<?php
	
error_reporting(E_ERROR);
	require('config.php');   
							
								
	                      $sql = mysql_query("SELECT * FROM `analysis`");
						  
		                  while($cats_row = mysql_fetch_array($sql))
							{
								$website = $cats_row['website'];
								$id = $cats_row['id'];
							    $string = "select $website from `browsing`";
								$addsite = mysql_query($string);
								$visits = 0;
								$reach = 0;
								 while($cats_site = mysql_fetch_array($addsite))
						       	{
								  $visits = $visits + $cats_site[$website]; 
								  if($cats_site[$website]>=1)
								  $reach ++;
		                       }
							  
							   $run1 = mysql_query("UPDATE `cgt`.`analysis` SET `reachability` = $reach WHERE `analysis`.`id` = $id;");
							   $run2 = mysql_query("UPDATE `cgt`.`analysis` SET `browsers` = $visits WHERE `analysis`.`id` = $id;");
							   
		                    }

/*Results*/

                            $get_results = "SELECT * FROM analysis ORDER BY browsers DESC";
							$runs_cats = mysql_query($get_results);
							echo "
						
								 <table class='table table-bordered table-hover'>
                                <thead>
                                    <tr>
                                        <th>Rank</th>
                                        <th>Name of the website</th>
                                        <th>No. of Visits</th>
                                        <th>Reachability</th>
                                    </tr>
                                </thead>
                                
                                </table>
								
								";
								$rank = 1;
	                        while($cats_row = mysql_fetch_array($runs_cats))
							{
							     //echo 'fb here'.$facebook;     // UPDATE `cgt`.`analysis` SET `browsers` = '7' WHERE `analysis`.`id` = 1;
								$id = $cats_row['id'];
								$website = $cats_row['website'];
								$browsers = $cats_row['browsers'];
								$reachability = $cats_row['reachability']/3;
								$reachability *=100;
							    $reachability =  round($reachability, 2);
								
								
								echo "
									
								<table class='table table-bordered table-hover'>
                                
                                    <tr>
                                        <th style= 'width:122px'>$rank</th>
                                        <th style= 'width:360px'>$website</th>
                                        <th style= 'width:230px'>$browsers</th>
                                        <th>$reachability %</th>
                                    </tr>
                              
                                
                                </table>
								
							
								";
								
								$rank+=1;
		                    }
	                        
/*Results*/
?>
                               <!--php echo-->
						
						
						
                           
                        </div>
                    </div>

            </div>
			
			
			
			
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

</body>

</html>
