<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Network Analysis</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/sb-admin.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="css/plugins/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    
		
		
		<div class="row" style="color:white">
			<center>
			
<?php
 error_reporting(E_ERROR);
	require('config.php');
	$user_name = $_GET['user'];
	
	
	if(isset($_GET['user'])){
	
		//echo "Hello $user_name";
		
		
		if($user_name==""){
		
		echo "
		<center>
		<div style='padding-top:150px';><center>Please enter user name</center></div>
		
		<div style='padding-top:10px;'>
							<button class='btn btn-lg btn-default'><a href='login.php' style='text-decoration:none;'>Retry</a></button>  
							</div>
		</center>
		";
		}
		else{
		
		    $valid = 0;
		    $get_validity="select * from userlogin"; 
			$run_validity=mysql_query($get_validity);
			while($row = mysql_fetch_array($run_validity))
							{
							   
							   
							   $user=$row['username'];
							   //echo $user;
								if($user == $user_name) /*If user is found*/
								{
							    $valid = 1;
								break;
								}
							
							
							}
		
		
		/*paste here */
		          if($valid==1){
		           $get_id="select * from userlogin where username='$user_name'";  //Read 5 posts randomly
                        $run_posts=mysql_query($get_id);
						while($row_posts = mysql_fetch_array($run_posts))
							{
							   //echo "$row_posts";
							   if($row_posts){
							   $user_id=$row_posts['id'];
							   $user=$row_posts['username'];
							   
								if($user == $user_name) /*User is logged in already*/
								{
							    header("Location: user.php?uid=$user_id");
								break;
								}
								
								
							}
							
							}
							
						  }else{
						  
						  echo "
							<center>
							<div style='padding-top:150px';><center>Invalid User</center></div>
							<div style='padding-top:10px'>
							<div style='padding-top:10px;'>
							<button class='btn btn-lg btn-default'><a href='index.php' style='text-decoration:none;'>Retry</a></button>  
							</div>
							</div>
							</center>
							
							
							";
						  
						  }  
	
	}}
?>
			
			
			
			


			
			
			
			</center>
		</div>
        <!-- /#page-wrapper -->

    
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <!-- Morris Charts JavaScript -->
    <script src="js/plugins/morris/raphael.min.js"></script>
    <script src="js/plugins/morris/morris.min.js"></script>
    <script src="js/plugins/morris/morris-data.js"></script>

</body>

</html>
